#!/bin/bash
# Fire-Phisher v1.0 
# Coded by: Cyphersploit

# STARTING SCRIPT-----------------------------------------------------------------------------------------------------------STARTING SCRIPT
figlet   Fire-Phisher -w 150 | lolcat
printf "     \e[101m\e[1;77m:: Disclaimer: Developers assume no liability and are not        ::\e[0m\n"
printf "     \e[101m\e[1;77m:: responsible for any misuse or damage caused by Fire-Phisher.  ::\e[0m\n"
printf "     \e[101m\e[1;77m:: Only use for educational purporses!!                          ::\e[0m\n"
printf "\n"
printf "     \e[101m\e[1;77m::         Fire-Phisher Coded by : Cyphersploit                  ::\e[0m\n"
printf "\n"
read -p $'\n\e[1;92m[\e[0m\e[1;77m*\e[0m\e[1;92m] Enter Password : \e[0m\en' pass
if [[ $pass == subscribetoethicalprince ]]; then
clear
bash require
else
printf "\e[1;93m [!] Invalid Password! Please Watch Tutorial To Know The Password\e[0m\n"
fi





